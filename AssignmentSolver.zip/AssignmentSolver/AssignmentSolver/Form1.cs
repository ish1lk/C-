﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssignmentSolver
{
    public partial class Form1 : Form
    {
        private int rows = 4;
        private int cols = 4;
        private int[,] costMatrix;

        public Form1()
        {
            InitializeComponent();
            InitializeGrid(rows, cols);

            // Настройка панели с прокруткой для PictureBox
            panelGraph.AutoScroll = true;
            pictureBoxGraph.SizeMode = PictureBoxSizeMode.AutoSize;
            panelGraph.Controls.Add(pictureBoxGraph);
        }

        private void NudSize_ValueChanged(object sender, EventArgs e)
        {
            rows = (int)nudRows.Value;
            cols = (int)nudCols.Value;
            InitializeGrid(rows, cols);
        }

        private void InitializeGrid(int nRows, int nCols)
        {
            dataGridViewMatrix.Columns.Clear();
            dataGridViewMatrix.Rows.Clear();

            dataGridViewMatrix.ColumnCount = nCols;
            dataGridViewMatrix.RowCount = nRows;

            for (int i = 0; i < nCols; i++)
            {
                dataGridViewMatrix.Columns[i].Width = 50;
                dataGridViewMatrix.Columns[i].HeaderText = $"Задача{i + 1}";
            }

            for (int i = 0; i < nRows; i++)
            {
                dataGridViewMatrix.Rows[i].HeaderCell.Value = $"Работник{i + 1}";
            }

            // Заполнить значениями по умолчанию
            for (int r = 0; r < nRows; r++)
                for (int c = 0; c < nCols; c++)
                    dataGridViewMatrix.Rows[r].Cells[c].Value = 1 + r + c;
        }

        private bool ReadCostMatrix()
        {
            costMatrix = new int[rows, cols];
            try
            {
                for (int i = 0; i < rows; i++)
                    for (int j = 0; j < cols; j++)
                        costMatrix[i, j] = Convert.ToInt32(dataGridViewMatrix.Rows[i].Cells[j].Value);
            }
            catch
            {
                MessageBox.Show("Введите корректные целые числа в матрицу.", "Ошибка");
                return false;
            }
            return true;
        }

        private int[,] MakeSquareMatrix(int[,] rectMatrix)
        {
            int r = rectMatrix.GetLength(0);
            int c = rectMatrix.GetLength(1);
            int n = Math.Max(r, c);
            int[,] squareMatrix = new int[n, n];

            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    if (i < r && j < c)
                        squareMatrix[i, j] = rectMatrix[i, j];
                    else
                        squareMatrix[i, j] = 0; // Можно заменить на большое число, чтобы запретить назначение
                }

            return squareMatrix;
        }

        private void HighlightResult(List<(int row, int col)> assignment, Color color)
        {
            foreach (DataGridViewRow row in dataGridViewMatrix.Rows)
                foreach (DataGridViewCell cell in row.Cells)
                    cell.Style.BackColor = Color.White;

            foreach (var (row, col) in assignment)
            {
                if (row < dataGridViewMatrix.RowCount && col < dataGridViewMatrix.ColumnCount)
                    dataGridViewMatrix.Rows[row].Cells[col].Style.BackColor = color;
            }
        }

        private void btnSolveHungarian_Click(object sender, EventArgs e)
        {
            if (!ReadCostMatrix()) return;

            int[,] square = MakeSquareMatrix(costMatrix);

            int[] assignment = HungarianAlgorithm.Solve(square);

            var assignmentList = new List<(int row, int col)>();

            for (int i = 0; i < assignment.Length; i++)
            {
                if (i < rows && assignment[i] < cols)
                    assignmentList.Add((i, assignment[i]));
            }

            HighlightResult(assignmentList, Color.LightGreen);

            if (assignmentList.Count == 0)
            {
                pictureBoxGraph.Image = null;
            }
            else
            {
                DrawAssignmentGraph(assignmentList);
            }

            int totalCost = 0;
            foreach (var (row, col) in assignmentList)
                totalCost += costMatrix[row, col];

            MessageBox.Show($"Венгер: оптимальная стоимость = {totalCost}", "Результат");
        }

        private async void btnSolveBnB_Click(object sender, EventArgs e)
        {
            if (!ReadCostMatrix()) return;

            btnSolveBnB.Enabled = false;
            try
            {
                int[,] square = MakeSquareMatrix(costMatrix);

                var (assignment, totalCost) = await Task.Run(() => BranchAndBoundSolver.Solve(square));

                if (assignment == null)
                {
                    MessageBox.Show("Решение не найдено.", "Ошибка");
                    pictureBoxGraph.Image = null;
                    return;
                }

                var filtered = new List<(int row, int col)>();
                foreach (var (row, col) in assignment)
                {
                    if (row < rows && col < cols)
                        filtered.Add((row, col));
                }

                HighlightResult(filtered, Color.LightBlue);

                DrawAssignmentGraph(filtered);

                MessageBox.Show($"Ветви и границы: оптимальная стоимость = {totalCost}", "Результат");
            }
            finally
            {
                btnSolveBnB.Enabled = true;
            }
        }

        private void ClearMatrix(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridViewMatrix.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    cell.Value = null;
                }
            }
        }


        private void FillMatrixWithRandomValues(object sender, EventArgs e)
        {
            int rowCount = 9;
            int colCount = 9;
            int minValue = 0;
            int maxValue = 1000;

            dataGridViewMatrix.Rows.Clear();
            dataGridViewMatrix.Columns.Clear();

            for (int j = 0; j < colCount; j++)
            {
                dataGridViewMatrix.Columns.Add($"Task{j}", $"Задача{j + 1}");
            }

            Random rand = new Random();
            for (int i = 0; i < rowCount; i++)
            {
                object[] row = new object[colCount];
                for (int j = 0; j < colCount; j++)
                {
                    row[j] = rand.Next(minValue, maxValue + 1);
                }
                dataGridViewMatrix.Rows.Add(row);
                dataGridViewMatrix.Rows[i].HeaderCell.Value = $"Работник{i + 1}";
            }

            dataGridViewMatrix.RowHeadersVisible = true;

            // Обновляем поля rows и cols, чтобы они соответствовали новым размерам
            rows = rowCount;
            cols = colCount;
        }

        private void DrawAssignmentGraph(List<(int worker, int job)> assignments)
        {
            if (assignments == null || assignments.Count == 0)
            {
                pictureBoxGraph.Image = null;
                return;
            }

            int width = Math.Max(pictureBoxGraph.Width, 360);
            int height = Math.Max(pictureBoxGraph.Height, 600);

            Bitmap bmp = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.White);
                Pen edgePen = new Pen(Color.Blue, 2);
                Brush workerBrush = Brushes.LightGreen;
                Brush jobBrush = Brushes.LightCoral;
                Brush textBrush = Brushes.Black;
                Font font = new Font("Arial", 10);

                int workerCount = assignments.Select(a => a.worker).Distinct().Count();
                int jobCount = assignments.Select(a => a.job).Distinct().Count();

                int margin = 60;
                int nodeGap = 200; // Расстояние между столбцами узлов (уменьшено)
                int workerSpacing = workerCount > 1 ? (height - 2 * margin) / (workerCount - 1) : 0;
                int jobSpacing = jobCount > 1 ? (height - 2 * margin) / (jobCount - 1) : 0;

                var workerPositions = new Dictionary<int, Point>();
                var jobPositions = new Dictionary<int, Point>();

                int workerX = (width - nodeGap) / 2;
                int jobX = (width + nodeGap) / 2;

                int i = 0;
                foreach (var w in assignments.Select(a => a.worker).Distinct())
                {
                    workerPositions[w] = new Point(workerX, margin + i * workerSpacing);
                    i++;
                }

                i = 0;
                foreach (var j in assignments.Select(a => a.job).Distinct())
                {
                    jobPositions[j] = new Point(jobX, margin + i * jobSpacing);
                    i++;
                }

                int nodeRadius = 20;

                // Нарисовать ребра с весами
                foreach (var assign in assignments)
                {
                    Point start = workerPositions[assign.worker];
                    Point end = jobPositions[assign.job];
                    g.DrawLine(edgePen, start.X + nodeRadius, start.Y, end.X - nodeRadius, end.Y);

                    // Рассчитать позицию для подписи веса
                    int midX = (start.X + end.X) / 2;
                    int midY = (start.Y + end.Y) / 2;

                    int cost = (assign.worker < rows && assign.job < cols) ? costMatrix[assign.worker, assign.job] : 0;
                    string costText = cost.ToString();

                    g.DrawString(costText, font, Brushes.DarkRed, midX + 5, midY - 15);
                }

                // Нарисовать узлы — рабочих
                foreach (var kvp in workerPositions)
                {
                    var p = kvp.Value;
                    g.FillEllipse(workerBrush, p.X - nodeRadius, p.Y - nodeRadius, nodeRadius * 2, nodeRadius * 2);
                    g.DrawEllipse(Pens.Black, p.X - nodeRadius, p.Y - nodeRadius, nodeRadius * 2, nodeRadius * 2);

                    SizeF textSize = g.MeasureString($"Работник{kvp.Key + 1}", font);
                    g.DrawString($"Работник{kvp.Key + 1}", font, textBrush, p.X - textSize.Width / 2, p.Y + nodeRadius + 2);
                }

                // Нарисовать узлы — задачи
                foreach (var kvp in jobPositions)
                {
                    var p = kvp.Value;
                    g.FillEllipse(jobBrush, p.X - nodeRadius, p.Y - nodeRadius, nodeRadius * 2, nodeRadius * 2);
                    g.DrawEllipse(Pens.Black, p.X - nodeRadius, p.Y - nodeRadius, nodeRadius * 2, nodeRadius * 2);

                    SizeF textSize = g.MeasureString($"Задача{kvp.Key + 1}", font);
                    g.DrawString($"Задача{kvp.Key + 1}", font, textBrush, p.X - textSize.Width / 2, p.Y + nodeRadius + 2);
                }
            }

            pictureBoxGraph.Image = bmp;

            // Обновляем размер pictureBox под размер картинки для прокрутки
            pictureBoxGraph.Width = bmp.Width;
            pictureBoxGraph.Height = bmp.Height;
        }


    }
}
