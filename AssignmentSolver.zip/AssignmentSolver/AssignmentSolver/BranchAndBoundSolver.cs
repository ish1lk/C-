﻿using System;
using System.Collections.Generic;

namespace AssignmentSolver
{
    // Простой метод ветвей и границ для задачи назначения (минимум)
    // Работает для квадратных матриц
    public static class BranchAndBoundSolver
    {
        private static int bestCost;
        private static List<(int, int)> bestAssignment;

        public static (List<(int, int)>, int) Solve(int[,] cost)
        {
            int n = cost.GetLength(0);
            bestCost = int.MaxValue;
            bestAssignment = null;

            var assignedCols = new bool[n];
            var currentAssignment = new List<(int, int)>();

            DFS(cost, 0, assignedCols, currentAssignment, 0);

            return (bestAssignment, bestCost);
        }

        private static void DFS(int[,] cost, int row, bool[] assignedCols, List<(int, int)> currentAssignment, int currentCost)
        {
            int n = cost.GetLength(0);
            if (row == n)
            {
                if (currentCost < bestCost)
                {
                    bestCost = currentCost;
                    bestAssignment = new List<(int, int)>(currentAssignment);
                }
                return;
            }

            // Оценка нижней грани
            int estimate = currentCost + EstimateLowerBound(cost, row, assignedCols);
            if (estimate >= bestCost) return;

            for (int col = 0; col < n; col++)
            {
                if (!assignedCols[col])
                {
                    assignedCols[col] = true;
                    currentAssignment.Add((row, col));
                    DFS(cost, row + 1, assignedCols, currentAssignment, currentCost + cost[row, col]);
                    currentAssignment.RemoveAt(currentAssignment.Count - 1);
                    assignedCols[col] = false;
                }
            }
        }

        private static int EstimateLowerBound(int[,] cost, int startRow, bool[] assignedCols)
        {
            int n = cost.GetLength(0);
            int estimate = 0;

            for (int row = startRow; row < n; row++)
            {
                int minCost = int.MaxValue;
                for (int col = 0; col < n; col++)
                {
                    if (!assignedCols[col] && cost[row, col] < minCost)
                        minCost = cost[row, col];
                }
                if (minCost == int.MaxValue) minCost = 0;
                estimate += minCost;
            }
            return estimate;
        }
    }
}
