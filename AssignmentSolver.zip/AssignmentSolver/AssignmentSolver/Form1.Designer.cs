﻿namespace AssignmentSolver
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dataGridViewMatrix;
        private System.Windows.Forms.Button btnSolveHungarian;
        private System.Windows.Forms.Button btnSolveBnB;
        private System.Windows.Forms.NumericUpDown nudRows;
        private System.Windows.Forms.NumericUpDown nudCols;
        private System.Windows.Forms.Label labelRows;
        private System.Windows.Forms.Label labelCols;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;

        // Добавим PictureBox для графа
        private System.Windows.Forms.PictureBox pictureBoxGraph;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dataGridViewMatrix = new System.Windows.Forms.DataGridView();
            this.btnSolveHungarian = new System.Windows.Forms.Button();
            this.btnSolveBnB = new System.Windows.Forms.Button();
            this.nudRows = new System.Windows.Forms.NumericUpDown();
            this.nudCols = new System.Windows.Forms.NumericUpDown();
            this.labelRows = new System.Windows.Forms.Label();
            this.labelCols = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBoxGraph = new System.Windows.Forms.PictureBox();
            this.panelGraph = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMatrix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRows)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCols)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGraph)).BeginInit();
            this.panelGraph.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewMatrix
            // 
            this.dataGridViewMatrix.AllowUserToAddRows = false;
            this.dataGridViewMatrix.AllowUserToDeleteRows = false;
            this.dataGridViewMatrix.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMatrix.Location = new System.Drawing.Point(26, 34);
            this.dataGridViewMatrix.Name = "dataGridViewMatrix";
            this.dataGridViewMatrix.RowHeadersWidth = 60;
            this.dataGridViewMatrix.RowTemplate.Height = 24;
            this.dataGridViewMatrix.Size = new System.Drawing.Size(413, 562);
            this.dataGridViewMatrix.TabIndex = 0;
            // 
            // btnSolveHungarian
            // 
            this.btnSolveHungarian.Location = new System.Drawing.Point(56, 44);
            this.btnSolveHungarian.Name = "btnSolveHungarian";
            this.btnSolveHungarian.Size = new System.Drawing.Size(209, 42);
            this.btnSolveHungarian.TabIndex = 1;
            this.btnSolveHungarian.Text = "Решить Венгером";
            this.btnSolveHungarian.UseVisualStyleBackColor = true;
            this.btnSolveHungarian.Click += new System.EventHandler(this.btnSolveHungarian_Click);
            // 
            // btnSolveBnB
            // 
            this.btnSolveBnB.Location = new System.Drawing.Point(56, 105);
            this.btnSolveBnB.Name = "btnSolveBnB";
            this.btnSolveBnB.Size = new System.Drawing.Size(209, 66);
            this.btnSolveBnB.TabIndex = 2;
            this.btnSolveBnB.Text = "Решить Ветвями и Границами";
            this.btnSolveBnB.UseVisualStyleBackColor = true;
            this.btnSolveBnB.Click += new System.EventHandler(this.btnSolveBnB_Click);
            // 
            // nudRows
            // 
            this.nudRows.Location = new System.Drawing.Point(175, 48);
            this.nudRows.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudRows.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRows.Name = "nudRows";
            this.nudRows.Size = new System.Drawing.Size(60, 31);
            this.nudRows.TabIndex = 3;
            this.nudRows.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nudRows.ValueChanged += new System.EventHandler(this.NudSize_ValueChanged);
            // 
            // nudCols
            // 
            this.nudCols.Location = new System.Drawing.Point(175, 106);
            this.nudCols.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudCols.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCols.Name = "nudCols";
            this.nudCols.Size = new System.Drawing.Size(60, 31);
            this.nudCols.TabIndex = 4;
            this.nudCols.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nudCols.ValueChanged += new System.EventHandler(this.NudSize_ValueChanged);
            // 
            // labelRows
            // 
            this.labelRows.AutoSize = true;
            this.labelRows.Location = new System.Drawing.Point(63, 54);
            this.labelRows.Name = "labelRows";
            this.labelRows.Size = new System.Drawing.Size(90, 25);
            this.labelRows.TabIndex = 5;
            this.labelRows.Text = "Строки:";
            // 
            // labelCols
            // 
            this.labelCols.AutoSize = true;
            this.labelCols.Location = new System.Drawing.Point(63, 112);
            this.labelCols.Name = "labelCols";
            this.labelCols.Size = new System.Drawing.Size(106, 25);
            this.labelCols.TabIndex = 6;
            this.labelCols.Text = "Столбцы:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnSolveBnB);
            this.groupBox1.Controls.Add(this.btnSolveHungarian);
            this.groupBox1.Location = new System.Drawing.Point(471, 400);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(334, 196);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Методы";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.labelCols);
            this.groupBox2.Controls.Add(this.nudRows);
            this.groupBox2.Controls.Add(this.nudCols);
            this.groupBox2.Controls.Add(this.labelRows);
            this.groupBox2.Location = new System.Drawing.Point(471, 34);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(334, 314);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Свойства матрицы";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(56, 223);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(209, 59);
            this.button2.TabIndex = 8;
            this.button2.Text = "Заполнить случайно";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.FillMatrixWithRandomValues);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(56, 162);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(209, 42);
            this.button1.TabIndex = 7;
            this.button1.Text = "Очистить матрицу";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.ClearMatrix);
            // 
            // pictureBoxGraph
            // 
            this.pictureBoxGraph.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxGraph.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxGraph.Name = "pictureBoxGraph";
            this.pictureBoxGraph.Size = new System.Drawing.Size(363, 588);
            this.pictureBoxGraph.TabIndex = 9;
            this.pictureBoxGraph.TabStop = false;
            // 
            // panelGraph
            // 
            this.panelGraph.Controls.Add(this.pictureBoxGraph);
            this.panelGraph.Location = new System.Drawing.Point(842, 38);
            this.panelGraph.Name = "panelGraph";
            this.panelGraph.Size = new System.Drawing.Size(363, 588);
            this.panelGraph.TabIndex = 10;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(1217, 647);
            this.Controls.Add(this.panelGraph);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridViewMatrix);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Программный комплекс решения задач о назначениях";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMatrix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRows)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCols)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGraph)).EndInit();
            this.panelGraph.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Panel panelGraph;
    }
}
